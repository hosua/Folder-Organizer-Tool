import os
dir = "F:\\Emulator Stuff\\ROMs\PS1\\1G1R"

def get_names():
    f = open("namelist.txt", "w")
    for file in os.listdir(dir):
        f.write(file.replace("chd", "txt"))

def create_dummy_files():
    f = open("namelist.txt", "r")
    if not os.path.isdir("Test Files"):
        os.mkdir("Test Files")
    
    new_dir = os.path.join(os.getcwd(), "Test Files")
    os.chdir(new_dir)
    for name in f.readlines():
        print("Created " + name + " in " + new_dir)
        g = open(name.strip("\n"), "w")
        g.close()
    
create_dummy_files()