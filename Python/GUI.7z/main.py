import folder_organizer_tool as fo
from gui import Folder_Organizer_Tool
from colorama import Fore, Back, Style

FOT = Folder_Organizer_Tool()

FOT.display_GUI()
